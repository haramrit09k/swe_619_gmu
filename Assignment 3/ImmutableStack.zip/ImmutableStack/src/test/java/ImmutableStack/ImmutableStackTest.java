/**
 * Junit Test Cases for Bloch's Stack Example converted to an Immutable Stack
 * @author: Haramrit Singh Khurana
 */

package ImmutableStack;

import org.junit.Test;
import static org.junit.Assert.*;

public class ImmutableStackTest {

    @Test
    public void Test_ImmutableStack_Push() {
        ImmutableStack st = new ImmutableStack().push("Cat");
        assertNotSame("New ImmutableStack object created with push operation", st.push("Cat"), st);
    }

    @Test
    public void Test_ImmutableStack_Pop() {
        ImmutableStack st = new ImmutableStack().push("Cat").push("Dog").push("Mouse").pop();
        assertNotSame("New ImmutableStack object returned after pop operation",
                st.push("Cat").push("Dog").push("Mouse").pop(), st);
    }

    @Test(expected = IllegalStateException.class)
    public void Test_ImmutableStack_EmptyStack_Pop() {
        new ImmutableStack().pop();
    }

    @Test
    public void Test_ImmutableStack_TopElement() {
        Object ob = new ImmutableStack().push("Cat").push("Dog").push("Mouse").viewTopElement();
        assertTrue("The top of the ImmutableStack is of type Object", ob instanceof Object);
    }

    @Test(expected = IllegalStateException.class)
    public void Test_ImmutableStack_EmptyStack_Top() {
        new ImmutableStack().viewTopElement();
    }

}
